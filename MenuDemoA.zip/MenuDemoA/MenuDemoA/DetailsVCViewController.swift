//
//  DetailsVCViewController.swift
//  MenuDemoA
//
//  Created by 2266727 on 04/04/23.
//

import UIKit

class DetailsVCViewController: UIViewController {
    
    var detailType = ""
    
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var HiL: UILabel!
    
    var empList: [Employee] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        print("viewdidload")
        
        tbl.dataSource = self
        tbl.delegate = self
    }
    func setupData(){
        empList.append(Employee(name: "Balaganesh", friendID: 1, mobileNum: "111", salary: 1000.0))
        
        empList.append(Employee(name: "Bhuvi", friendID: 2, mobileNum: "222", salary: 2000.0))
        
        empList.append(Employee(name: "Thilo", friendID: 3, mobileNum: "333", salary: 3000.0))
        
        empList.append(Employee(name: "Selva", friendID: 4, mobileNum: "444", salary: 4000.0))
    }
    
    
    @IBAction func sortClick(_ sender: UIBarButtonItem) {
        
        empList.sort { emp1, emp2 in
            return emp1.salary > emp2.salary
        }
        
        tbl.reloadData()
    }
    
    @IBAction func addClick(_ sender: UIBarButtonItem) {
        let alertVC = UIAlertController(title: "New Name", message: nil, preferredStyle: .alert)
        
        alertVC.addTextField(){ tf in
            tf.placeholder = "Name"
        }
        
        alertVC.addTextField(){ tf in
            tf.placeholder = "Mobile Number"
        }
        
        alertVC.addTextField(){ tf in
            tf.placeholder = "Salary"
        }
        
        alertVC.addTextField(){ tf in
            tf.placeholder = "Friend ID"
        }
        
        let addEmpAction = UIAlertAction(title: "ADD Employee", style: .default) { _ in
            
            let friendName = alertVC.textFields?[0].text ?? ""
            let mobileN = alertVC.textFields?[1].text ?? ""
            let salary = alertVC.textFields?[2].text ?? ""
            let friendId = alertVC.textFields?[3].text ?? ""
            
            let emp = Employee(name: friendName, friendID: Int(friendId) ?? 1, mobileNum: mobileN, salary: Double(salary) ?? 1000.0)
            
            self.empList.append(emp)
            print("friend added..")
            self.tbl.reloadData()
            
        }
        
        alertVC.addAction(addEmpAction)
        
        present(alertVC, animated: true)
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        print("viewwillappear")
        HiL.text = "Welcome \(detailType)"
        setupData()
        tbl.reloadData()
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        print("view did disapper")
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension DetailsVCViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return empList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //1. cell reference
       let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! EmployeeCell
        
        
        //2. data binding
        let emp = empList[indexPath.row]
        cell.nameL.text = emp.name
        cell.mobileL.text = emp.mobileNum
        cell.salaryL.text = "\(emp.salary)"
        cell.friendIDL.text = "\(emp.friendID)"
        
        return cell
    }
    
    
    
}

extension DetailsVCViewController : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        print("Right swipe done for \(empList[indexPath.row].name)")
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _, _, _ in
            self.empList.remove(at: indexPath.row)
            // table to be reloaded...
            self.tbl.reloadData()
            print("Deleted...")
            
        }
        
        let config = UISwipeActionsConfiguration(actions: [deleteAction])
        return config
    }
    
    func tableView(_ tableView: UITableView, contextMenuConfigurationForRowAt indexPath: IndexPath, point: CGPoint) -> UIContextMenuConfiguration? {
        
        // configure menu and return
        
        var emp = empList[indexPath.row]
        
        let menuConfig = UIContextMenuConfiguration(actionProvider:  { _ in
            
            let editAction = UIAction(title: "Edit") { _ in
                print("Editing..")
                emp.name = emp.name.uppercased()
                self.empList[indexPath.row] = emp
                self.tbl.reloadData()
            }
            
            let deleteAction = UIAction(title: "Delete") { _ in
               
                self.empList.remove(at: indexPath.row)
                // table to be reloaded...
                self.tbl.reloadData()
                print("Deleted...")
            }
            
            let menu = UIMenu(title: "\(emp.name)", children: [editAction, deleteAction])
            
            return menu
        })
    
        return menuConfig
    }
}


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


