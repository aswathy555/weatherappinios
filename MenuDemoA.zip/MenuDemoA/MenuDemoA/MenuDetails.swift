//
//  MenuDetails.swift
//  MenuDemoA
//
//  Created by 2266727 on 04/04/23.
//

import Foundation

struct Employee{
    var name: String
    var friendID: Int
    var mobileNum: String
    var salary: Double
}
