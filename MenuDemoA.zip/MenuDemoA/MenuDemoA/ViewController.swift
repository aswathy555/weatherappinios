//
//  ViewController.swift
//  MenuDemoA
//
//  Created by 2266727 on 04/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ContinueB: UIButton!
    
    
    func setupNavigationBar() {
        navigationItem.title = "HomePage"
        
        
        
        //        let loginBarButton = UIBarButtonItem(title: "Login", style: .plain, target: self, action: #selector(doLogin))
        
        
        let guestAction = UIAction(title: "Guest") { _ in
            print("Guest type selected")
        }
        
        let friendAction = UIAction(title: "Friends") { _ in
            print("Friend type selected")
        }
        
        let familyAction = UIAction(title: "Family") { _ in
            print("Family type selected")
        }
        
        let userTypeMenu = UIMenu(title: "Continue as", children: [friendAction, familyAction, guestAction])
        
        let loginBarButton = UIBarButtonItem(title: "Login", menu: userTypeMenu)
        
        
        // loginBarButton.menu = userTypeMenu
        
        
        navigationItem.rightBarButtonItem = loginBarButton
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
   
        setupButton()
        
        setupNavigationBar()
    }

@objc
func doLogin(){
    print("Login selected")
}

func setupButton(){
    // design menu and associate to button
    
    let vc = storyboard?.instantiateViewController(withIdentifier: "detailvc") as! DetailsVCViewController
    
    
    
    let guestAction = UIAction(title: "Guest") { _ in
        print("Guest type selected")
        vc.detailType = "Guest"
        self.show(vc, sender: self)
    }
    
    let friendAction = UIAction(title: "Friend") { _ in
        print("friend type selected")
        vc.detailType = "Friend"
        self.show(vc, sender: self)
    }
    
    let familyAction = UIAction(title: "Family") { _ in
        print("family type selected")
        vc.detailType = "Family"
        self.show(vc, sender: self)
    }
    
    let userTypeMenu = UIMenu(title: "Continue as", children: [friendAction, familyAction, guestAction])
    
    ContinueB.menu = userTypeMenu
    ContinueB.showsMenuAsPrimaryAction = true
}

}




