//
//  EmployeeCell.swift
//  MenuDemoA
//
//  Created by 2266727 on 04/04/23.
//

import UIKit

class EmployeeCell: UITableViewCell {

    @IBOutlet weak var nameL: UILabel!
    
    @IBOutlet weak var salaryL: UILabel!
    
    @IBOutlet weak var friendIDL: UILabel!
    
    @IBOutlet weak var mobileL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
